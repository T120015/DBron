fn=$1

if [ $# -eq 1 ]; then
    # 日付
    dd=$(date '+%Y/%m/%d')
    dt=$(date '+%H:%M:%S')

    # バイナリ化
    a=$(cat "$fn" | xxd -p)
    # 日時、ファイル名のバイナリ化
    ddb=$(echo "$dd" | xxd -p)
    dtb=$(echo "$dt" | xxd -p)
    fnb=$(echo "$fn" | xxd -p)

    # 改行と半角スペースを除く
    b=$(echo ${a} | sed "s/ //g")
    # 書き込み 日 時 ファイル名 ファイルの中身
    echo "$ddb" "$dtb" "$fnb" "$b" >> /workdir/log/difflog.dat

    # git各種操作
    git add .
    git commit -m "$dd-$dt"
    git log --numstat --oneline --pretty=format:'%cd %an %s' --date=format:'%Y/%m/%d %H:%M:%S' --reverse > /workdir/log/gitlog.log
    echo "$dd" "$dt" "$fn" >> /workdir/log/execlog.log
    echo "--------------------------------------"
    python $fn
else
    echo "実行するファイル名のパスを入力してください"
fi